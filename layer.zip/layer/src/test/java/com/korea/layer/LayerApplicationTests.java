package com.korea.layer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LayerApplicationTests {

	@Test
	void contextLoads() {
	}

}
